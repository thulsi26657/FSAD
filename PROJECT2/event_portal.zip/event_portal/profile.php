<?php
include 'layout.php';
include 'db.php';

$user_id = $_SESSION['user_id'];

// Fetch user
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$message = "";

// Update profile
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];

    $stmt = $conn->prepare("UPDATE users SET name=? WHERE id=?");
    $stmt->bind_param("si", $name, $user_id);

    if ($stmt->execute()) {
        $message = "✅ Profile updated!";
        $_SESSION['user_name'] = $name;
    } else {
        $message = "❌ Update failed!";
    }
}
?>

<div class="container mt-4">

<h3>👤 My Profile</h3>

<?php if ($message): ?>
<div class="alert alert-success"><?php echo $message; ?></div>
<?php endif; ?>

<div class="row mt-4">

<!-- Profile Card -->
<div class="col-md-4">
<div class="card shadow text-center p-4">

<img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
     width="100" class="mx-auto mb-3">

<h5><?php echo $user['name']; ?></h5>
<p class="text-muted"><?php echo $user['email']; ?></p>

</div>
</div>

<!-- Edit Form -->
<div class="col-md-8">
<div class="card shadow p-4">

<h5>Edit Profile</h5>

<form method="POST">

<div class="mb-3">
<label>Name</label>
<input type="text" name="name" value="<?php echo $user['name']; ?>" class="form-control">
</div>

<div class="mb-3">
<label>Email</label>
<input type="email" value="<?php echo $user['email']; ?>" class="form-control" disabled>
</div>

<button class="btn btn-primary">Update</button>

</form>

</div>
</div>

</div>

</div>

</div>
</body>
</html>