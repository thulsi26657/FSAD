<?php
include 'layout.php';
include 'db.php';

// Total Students
$total_students = $conn->query("
SELECT COUNT(DISTINCT user_id) AS total
FROM registrations
")->fetch_assoc()['total'];

// Total Events
$total_events = $conn->query("
SELECT COUNT(*) AS c 
FROM events
")->fetch_assoc()['c'];

// Total Registrations
$total_regs = $conn->query("
SELECT COUNT(*) AS c 
FROM registrations
")->fetch_assoc()['c'];

// Recent Events
$events = $conn->query("
SELECT * 
FROM events 
ORDER BY id DESC 
LIMIT 3
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#f4f6f9;
}

.stat-card{
    border-radius:15px;
    color:white;
    padding:25px;
    transition:0.3s;
}

.stat-card:hover{
    transform:translateY(-5px);
}

.bg-blue{
    background:linear-gradient(45deg,#4e73df,#224abe);
}

.bg-green{
    background:linear-gradient(45deg,#1cc88a,#13855c);
}

.bg-yellow{
    background:linear-gradient(45deg,#f6c23e,#dda20a);
}

.event-card{
    border-radius:12px;
    transition:0.3s;
}

.event-card:hover{
    transform:scale(1.03);
}

</style>
</head>

<body>

<div class="container mt-4">

<h3 class="mb-4">
👋 Welcome, <?php echo $_SESSION['user_name']; ?>
</h3>

<!-- STATS -->
<div class="row mb-4">

<div class="col-md-4">
<div class="stat-card bg-blue shadow">

<h2><?php echo $total_events; ?></h2>

<p>Total Events</p>

</div>
</div>

<div class="col-md-4">
<div class="stat-card bg-green shadow">

<h2><?php echo $total_regs; ?></h2>

<p>Total Registrations</p>

</div>
</div>

<div class="col-md-4">
<div class="stat-card bg-yellow shadow">

<h2><?php echo $total_students; ?></h2>

<p>Total Students</p>

</div>
</div>

</div>

<!-- QUICK ACTIONS -->
<div class="mb-4">

<a href="events.php" class="btn btn-primary me-2">
📅 View Events
</a>

<a href="my_events.php" class="btn btn-warning">
📌 My Events
</a>

</div>

<!-- RECENT EVENTS -->
<h4 class="mb-3">🔥 Recent Events</h4>

<div class="row">

<?php while($row = $events->fetch_assoc()) { ?>

<div class="col-md-4">

<div class="card event-card shadow p-3 mb-3">

<h5><?php echo $row['event_name']; ?></h5>

<p class="mb-1">
📅 <?php echo $row['date']; ?>
</p>

<p class="mb-1">
📍 <?php echo $row['location']; ?>
</p>

<a href="register_event.php?id=<?php echo $row['id']; ?>"
   class="btn btn-success w-100 mt-2">

   Register

</a>

</div>
</div>

<?php } ?>

</div>

</div>

</body>
</html>