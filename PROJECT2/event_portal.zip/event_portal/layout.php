<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Event Portal</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    margin: 0;
    font-family: Arial;
}

/* Sidebar */
.sidebar {
    height: 100vh;
    width: 220px;
    position: fixed;
    background: #343a40;
    padding-top: 20px;
}

.sidebar a {
    display: block;
    color: white;
    padding: 12px;
    text-decoration: none;
}

.sidebar a:hover {
    background: #495057;
}

/* Content */
.content {
    margin-left: 220px;
    padding: 20px;
}

/* Topbar */
.topbar {
    background: #212529;
    color: white;
    padding: 10px;
}
</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h4 class="text-white text-center">🎓 Portal</h4>

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="add_event.php">➕ Add Event</a>
    <a href="events.php">📅 Events</a>
    <a href="my_events.php">📌 My Events</a>
    
<li>
   <a href="student_details.php">🎓 Student Details</a>
</li>
    <a href="profile.php">👤 Profile</a>
    <a href="logout.php">🚪 Logout</a>
</div>

<!-- Content -->
<div class="content">

<div class="topbar">
    Welcome, <?php echo $_SESSION['user_name']; ?>
</div>