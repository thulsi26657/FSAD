<?php
include 'layout.php';
include 'db.php';

$user_id = $_SESSION['user_id'];

$result = $conn->query("
SELECT events.*, registrations.reg_date 
FROM registrations
JOIN events ON registrations.event_id = events.id
WHERE registrations.user_id = '$user_id'
ORDER BY events.date DESC
");
?>

<div class="container mt-4">

<h3 class="mb-4">📌 My Events</h3>

<div class="row">

<?php if ($result->num_rows > 0) { ?>

<?php while($row = $result->fetch_assoc()) { 

$status = (strtotime($row['date']) < time()) ? "Completed" : "Upcoming";

?>

<div class="col-md-4">
<div class="card shadow event-card p-3 mb-4">

<!-- TITLE -->
<h5><?php echo $row['event_name']; ?></h5>

<!-- STATUS -->
<span class="badge 
<?php echo ($status == 'Upcoming') ? 'bg-success' : 'bg-secondary'; ?>">
<?php echo $status; ?>
</span>

<!-- DETAILS -->
<p class="mt-2 mb-1">📅 <?php echo $row['date']; ?></p>
<p class="mb-1">📍 <?php echo $row['location']; ?></p>

<p class="text-muted small">
<?php echo $row['description']; ?>
</p>

<!-- REGISTER DATE -->
<p class="small text-info">
Registered on: <?php echo date("d M Y", strtotime($row['reg_date'])); ?>
</p>

<!-- ACTION -->
<a href="cancel.php?id=<?php echo $row['id']; ?>" 
   class="btn btn-danger w-100">
   Cancel Registration
</a>

</div>
</div>

<?php } ?>

<?php } else { ?>

<!-- EMPTY STATE -->
<div class="text-center mt-5">
<h5>No events registered yet 😔</h5>
<a href="events.php" class="btn btn-primary mt-3">Browse Events</a>
</div>

<?php } ?>

</div>

</div>

<style>
.event-card {
    border-radius: 15px;
    transition: 0.3s;
}
.event-card:hover {
    transform: translateY(-5px);
}
</style>

</div>
</body>
</html>