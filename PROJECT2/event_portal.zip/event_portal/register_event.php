<?php
include 'db.php';
session_start();

// 🔒 Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$event_id = $_GET['id'] ?? 0;

// Validate event
$stmt = $conn->prepare("SELECT * FROM events WHERE id=?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event = $stmt->get_result()->fetch_assoc();

if (!$event) {
    die("❌ Invalid event");
}

// Check already registered
$stmt = $conn->prepare("SELECT id FROM registrations WHERE user_id=? AND event_id=?");
$stmt->bind_param("ii", $user_id, $event_id);
$stmt->execute();
$check = $stmt->get_result();

if ($check->num_rows > 0) {
    header("Location: events.php?msg=already");
    exit();
}

// Check capacity
$count = $conn->query("SELECT COUNT(*) as c FROM registrations WHERE event_id='$event_id'")->fetch_assoc()['c'];
$capacity = $event['capacity'] ?? 50;

if ($count >= $capacity) {
    header("Location: events.php?msg=full");
    exit();
}

// Insert registration
$stmt = $conn->prepare("INSERT INTO registrations (user_id, event_id) VALUES (?, ?)");
$stmt->bind_param("ii", $user_id, $event_id);

if ($stmt->execute()) {
    header("Location: my_events.php?msg=success");
} else {
    echo "❌ Error registering";
}
?>