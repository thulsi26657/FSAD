<?php
session_start();
session_destroy();
header("Location: login.php");
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand" href="dashboard.php">Event Portal</a>

<div>
<a href="events.php" class="btn btn-light">Events</a>
<a href="my_events.php" class="btn btn-warning">My Events</a>
<a href="add_event.php">➕ Add Event</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>

</div>
</nav>