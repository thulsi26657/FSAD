<?php
include 'layout.php';
include 'db.php';

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get registered students details
$query = "
SELECT 
    u.name,
    u.email,
    e.event_name,
    e.date,
    e.location,
    r.registered_at
FROM registrations r
JOIN users u ON r.user_id = u.user_id
JOIN events e ON r.event_id = e.id
ORDER BY r.registered_at DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registered Students</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f4f6f9;
        }

        .table-container{
            background:white;
            padding:25px;
            border-radius:15px;
            box-shadow:0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>

<body>

<div class="container mt-5">

    <div class="table-container">

        <h3 class="mb-4">🎓 Registered Students</h3>

        <table class="table table-bordered table-hover">

            <thead class="table-dark">
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Event</th>
                    <th>Date</th>
                    <th>Location</th>
                    <th>Registered On</th>
                </tr>
            </thead>

            <tbody>

            <?php while($row = $result->fetch_assoc()) { ?>

                <tr>

                    <td><?php echo $row['name']; ?></td>

                    <td><?php echo $row['email']; ?></td>

                    <td><?php echo $row['event_name']; ?></td>

                    <td><?php echo $row['date']; ?></td>

                    <td><?php echo $row['location']; ?></td>

                    <td><?php echo $row['registered_at']; ?></td>
                    

                </tr>

            <?php } ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>