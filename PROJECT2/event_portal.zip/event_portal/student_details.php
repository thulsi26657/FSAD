<?php
include 'layout.php';
include 'db.php';

// Get registered student details
$query = "



SELECT 
   u.id AS user_id,
    u.name,
    u.email,
    e.event_name,
    e.date,
    e.location

FROM registrations r

JOIN users u ON r.user_id = u.id

JOIN events e ON r.event_id = e.id

";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Details</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
            background:#f4f6f9;
        }

        .table-box{
            background:white;
            padding:25px;
            border-radius:15px;
            box-shadow:0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>

<body>

<div class="container mt-5">

<div class="table-box">

<h3 class="mb-4">🎓 Registered Student Details</h3>

<table class="table table-bordered table-hover">

<thead class="table-dark">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Event</th>
    <th>Date</th>
    <th>Location</th>
    
</tr>
</thead>

<tbody>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>
<td><?php echo $row['id']; ?></td>

<td><?php echo $row['name']; ?></td>

<td><?php echo $row['email']; ?></td>

<td><?php echo $row['event_name']; ?></td>

<td><?php echo $row['date']; ?></td>

<td><?php echo $row['location']; ?></td>



</tr>

<?php } ?>

</tbody>

</table>

</div>

</div>

</body>
</html>