<?php
include 'layout.php';
include 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['name']);
    $date = $_POST['date'];
    $location = trim($_POST['location']);
    $description = trim($_POST['description']);
    $capacity = $_POST['capacity'];

    // Image upload
    $image = "default.png";

    if (!empty($_FILES['image']['name'])) {

        $target = "uploads/" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);

        $image = $_FILES['image']['name'];
    }

    // Insert
    $stmt = $conn->prepare("
    INSERT INTO events (event_name, date, location, description, capacity, image)
    VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param("ssssis", $name, $date, $location, $description, $capacity, $image);

    if ($stmt->execute()) {
        $message = "✅ Event added successfully!";
    } else {
        $message = "❌ Error adding event!";
    }

    $stmt->close();
}
?>

<div class="container mt-4">

<h3>➕ Add Event</h3>

<?php if ($message): ?>
<div class="alert alert-info"><?php echo $message; ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data" class="card p-4 shadow mt-4">

<div class="row">

<div class="col-md-6 mb-3">
<label>Event Name</label>
<input type="text" name="name" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Date</label>
<input type="date" name="date" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Location</label>
<input type="text" name="location" class="form-control" required>
</div>

<div class="col-md-6 mb-3">
<label>Capacity</label>
<input type="number" name="capacity" class="form-control" value="50">
</div>

<div class="col-12 mb-3">
<label>Description</label>
<textarea name="description" class="form-control" required></textarea>
</div>

<div class="col-12 mb-3">
<label>Upload Image</label>
<input type="file" name="image" class="form-control">
</div>

</div>

<button class="btn btn-success w-100">Add Event</button>

</form>

</div>

<style>
.card {
    border-radius: 15px;
}
</style>

</div>
</body>
</html>