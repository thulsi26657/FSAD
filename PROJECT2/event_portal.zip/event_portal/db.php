<?php
$conn = new mysqli("localhost", "root", "", "event_portal");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand" href="dashboard.php">Event Portal</a>



</div>
</nav>