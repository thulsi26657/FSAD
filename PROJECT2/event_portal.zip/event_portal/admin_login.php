<?php
session_start();

if ($_POST) {
    if ($_POST['username']=="admin" && $_POST['password']=="admin123") {
        $_SESSION['admin']=true;
        header("Location: admin_dashboard.php");
    } else {
        echo "Invalid";
    }
}
?>

<form method="POST">
<input name="username" placeholder="Username"><br>
<input type="password" name="password" placeholder="Password"><br>
<button>Login</button>
</form>
