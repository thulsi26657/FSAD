<?php
include 'db.php';

$id = $_GET['id'];

if ($_POST) {
    $conn->query("UPDATE events SET event_name='$_POST[name]' WHERE id='$id'");
    echo "Updated!";
}

$data = $conn->query("SELECT * FROM events WHERE id='$id'")->fetch_assoc();
?>

<form method="POST">
<input name="name" value="<?php echo $data['event_name']; ?>">
<button>Update</button>
</form>