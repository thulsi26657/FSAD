<?php
include 'db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Check if email exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $message = "⚠️ Email already registered!";
    } else {

        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashed_password);

        if ($stmt->execute()) {
            $message = "✅ Registration successful!";
        } else {
            $message = "❌ Error occurred!";
        }
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register - Event Portal</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(to right, #667eea, #764ba2);
        }

        .register-card {
            max-width: 420px;
            margin: 80px auto;
            padding: 25px;
            border-radius: 12px;
        }

        .form-control {
            border-radius: 8px;
        }

        .btn-custom {
            background: #28a745;
            color: white;
            font-weight: bold;
        }

        .btn-custom:hover {
            background: #218838;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="card shadow register-card">

        <h3 class="text-center mb-3">📝 Create Account</h3>

        <!-- Alert -->
        <?php if ($message): ?>
            <div class="alert alert-info text-center">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="mb-3">
                <label><i class="bi bi-person"></i> Name</label>
                <input type="text" name="name" class="form-control" placeholder="Enter your name" required>
            </div>

            <div class="mb-3">
                <label><i class="bi bi-envelope"></i> Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
            </div>

            <div class="mb-3">
                <label><i class="bi bi-lock"></i> Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>
            INSERT INTO registrations (user_id, event_id)VALUES (?, ?);
            <button class="btn btn-custom w-100">Register</button>
            

        </form>

        <div class="text-center mt-3">
            <a href="login.php">Already have an account? Login</a>
        </div>

    </div>

</div>

</body>
</html>