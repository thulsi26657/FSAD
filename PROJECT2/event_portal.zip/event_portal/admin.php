<?php
include 'db.php';

if ($_POST) {
    $conn->query("INSERT INTO events (event_name,date,location,description)
    VALUES ('$_POST[name]','$_POST[date]','$_POST[location]','$_POST[description]')");
    echo "Event added!";
    $result = $conn->query("SELECT * FROM events");

while ($row = $result->fetch_assoc()) {
    echo $row['event_name'];
    echo " <a href='?delete=".$row['id']."'>Delete</a><br>";
}
}
?>

<form method="POST" enctype="multipart/form-data">
<input name="name" placeholder="Event Name"><br>
<input type="date" name="date"><br>
<input name="location"><br>
<input name="description"><br>
<input type="file" name="image"><br>
<button>Add Event</button>
</form>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="container">
<a class="navbar-brand" href="dashboard.php">Event Portal</a>



</div>
</nav>