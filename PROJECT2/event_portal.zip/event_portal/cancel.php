<?php
include 'db.php';
session_start();

$user_id = $_SESSION['user_id'];
$event_id = $_GET['id'];

$conn->query("DELETE FROM registrations WHERE user_id='$user_id' AND event_id='$event_id'");

header("Location: events.php");
?>