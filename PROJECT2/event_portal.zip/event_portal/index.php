<!DOCTYPE html>
<html>
<head>
    <title>Event Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body style="background: linear-gradient(to right, #4facfe, #00f2fe);">

<div class="container text-center mt-5">
    <h1>🎓 Academic Event Portal</h1>

    <div class="card p-4 shadow mx-auto" style="width: 350px;">
        <a href="register.php" class="btn btn-success mb-2">Register</a>
        <a href="login.php" class="btn btn-primary mb-2">Login</a>
        <a href="admin_login.php" class="btn btn-dark">Admin</a>
    </div>
</div>

</body>
</html>
