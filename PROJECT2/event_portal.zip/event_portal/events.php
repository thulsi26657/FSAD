<?php
include 'layout.php';
include 'db.php';

$user_id = $_SESSION['user_id'];

// Search
$search = $_GET['search'] ?? "";

// Fetch events
$result = $conn->query("
SELECT * FROM events 
WHERE event_name LIKE '%$search%'
ORDER BY date DESC
");
?>

<div class="container mt-4">

<h3>📅 Events</h3>

<!-- SEARCH -->
<form method="GET" class="row mb-4 mt-3">
    <div class="col-md-4">
        <input type="text" name="search" class="form-control"
               placeholder="Search events..." value="<?php echo $search; ?>">
    </div>
    <div class="col-md-2">
        <button class="btn btn-primary">Search</button>
    </div>
</form>

<div class="row">

<?php while($row = $result->fetch_assoc()) { 

$event_id = $row['id'];

// Status
$status = (strtotime($row['date']) < time()) ? "Completed" : "Upcoming";

// Check registered
$check = $conn->query("
SELECT * FROM registrations 
WHERE user_id='$user_id' AND event_id='$event_id'
");

$isRegistered = $check->num_rows > 0;

// Capacity check
$count = $conn->query("SELECT COUNT(*) as c FROM registrations WHERE event_id='$event_id'")->fetch_assoc()['c'];
$capacity = $row['capacity'] ?? 50;
$isFull = $count >= $capacity;

?>

<div class="col-md-4">
<div class="card shadow mb-4 border-0 event-card">

<div class="card-body">

<!-- IMAGE -->
<img src="uploads/<?php echo $row['image'] ?? 'default.png'; ?>" 
     class="img-fluid rounded mb-3">

<!-- TITLE -->
<h5><?php echo $row['event_name']; ?></h5>

<!-- STATUS -->
<span class="badge 
<?php echo ($status == 'Upcoming') ? 'bg-success' : 'bg-secondary'; ?>">
<?php echo $status; ?>
</span>

<!-- DETAILS -->
<p class="mt-2 mb-1">📅 <?php echo $row['date']; ?></p>
<p class="mb-1">📍 <?php echo $row['location']; ?></p>

<p class="text-muted small">
<?php echo $row['description']; ?>
</p>

<!-- CAPACITY -->
<p class="small">
👥 <?php echo $count . "/" . $capacity; ?> seats filled
</p>

<!-- BUTTON LOGIC -->
<?php if ($isRegistered) { ?>

    <a href="cancel.php?id=<?php echo $event_id; ?>" 
       class="btn btn-danger w-100">Cancel</a>

<?php } elseif ($isFull) { ?>

    <button class="btn btn-secondary w-100" disabled>Full</button>

<?php } elseif ($status == "Completed") { ?>

    <button class="btn btn-dark w-100" disabled>Closed</button>

<?php } else { ?>

    <a href="register_event.php?id=<?php echo $event_id; ?>" 
       class="btn btn-success w-100">Register</a>

<?php } ?>

</div>
</div>
</div>

<?php } ?>

</div>

</div>

<style>
.event-card {
    border-radius: 15px;
    transition: 0.3s;
}
.event-card:hover {
    transform: scale(1.03);
}
</style>

</div>
</body>
</html>