<?php
include 'db.php';

$result = $conn->query("
SELECT users.name, users.email, events.event_name
FROM registrations
JOIN users ON users.id = registrations.user_id
JOIN events ON events.id = registrations.event_id
");

while ($row = $result->fetch_assoc()) {
    echo $row['name']." | ".$row['email']." | ".$row['event_name']."<br>";
}
?>
